
export default new Map([
["src/data/post/bitcoin-hits-new-high.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fdata%2Fpost%2Fbitcoin-hits-new-high.mdx&astroContentModuleFlag=true")],
["src/data/post/extreme-weather-explained.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fdata%2Fpost%2Fextreme-weather-explained.mdx&astroContentModuleFlag=true")],
["src/data/post/global-conflicts-latest.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fdata%2Fpost%2Fglobal-conflicts-latest.mdx&astroContentModuleFlag=true")],
["src/data/post/nvidia-surges-again-why-it-matters.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fdata%2Fpost%2Fnvidia-surges-again-why-it-matters.mdx&astroContentModuleFlag=true")],
["src/data/post/social-media-trends-2025.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fdata%2Fpost%2Fsocial-media-trends-2025.mdx&astroContentModuleFlag=true")],
["src/data/post/us-election-2025-what-to-know.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fdata%2Fpost%2Fus-election-2025-what-to-know.mdx&astroContentModuleFlag=true")]]);
		